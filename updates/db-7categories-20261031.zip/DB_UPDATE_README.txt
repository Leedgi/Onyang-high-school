﻿DB 업데이트: 기존91310b6 실행판 기준입니다.
앱을 종료하고 ZIP의 파일을 프로젝트 최상위에 같은 경로로 덮어쓴 뒤 run_windows.bat을 실행하세요.
이번에는 Python/의존성/모델 변경이 없으므로 setup 재실행이 필요 없습니다.
core·ui·shared·data를 함께 교체해야 합니다. .venv/.cache를 삭제하지 마세요.
추정 분류는 제조사 원료 확인·제품 안전성 판정이 아닙니다.

교체 파일:
core/analysis.py
core/classify.py
core/database.py
core/models.py
core/ratio.py
data/caution_additions.csv
data/caution_additions_sources.json
data/origin_additions.csv
data/origin_additions_round2.csv
data/origin_additions_round2_sources.json
data/origin_additions_round3.csv
data/origin_additions_round3_sources.json
data/origin_additions_round4.csv
data/origin_additions_round4_sources.json
data/origin_additions_sources.json
data/origin_detail_audit.csv
data/origin_taxonomy_sources.json
scripts/build_origin_data.py
scripts/build_taxonomy_data.py
shared/contracts.py
ui/presentation.py
ui/reporting.py
ui/site.py
